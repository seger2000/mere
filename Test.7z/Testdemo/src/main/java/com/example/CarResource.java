package com.example;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Path("/car")
public class CarResource {
 static public List<CarDomain> Car = new ArrayList<>();

 @GET
 @Produces({MediaType.APPLICATION_JSON})
 public Response getCars(){
        return Response.ok(Car).build();
 }
 @GET
 @Produces({MediaType.APPLICATION_JSON})
 @Path("/size")
 public Integer countCar(){
        return Car.size();
 }
 @POST
 @Produces({MediaType.APPLICATION_JSON})
 @Consumes({MediaType.APPLICATION_JSON})
 public Response addCar(CarDomain nameCar){
        Car.add(nameCar);
        return Response.ok(Car).build();
 }
 @DELETE
 @Path("{id}")
 @Consumes({MediaType.TEXT_PLAIN})
    public Response carDelete(@PathParam("id") Long id){
    Optional<CarDomain> carToDelete =  Car.stream().filter(Car -> Car.getId().equals(id)).findFirst();
     boolean removed = false;
     if(carToDelete.isPresent()){
         removed = Car.remove(carToDelete.get());;
     }
     if (removed){
         return Response.noContent().build();
     }
     return Response.status(Response.Status.BAD_REQUEST).build();

 }

}

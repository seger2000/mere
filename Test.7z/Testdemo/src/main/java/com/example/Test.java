package com.example;

public class Test {
    public static void main(String[] args) {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                System.out.println("test");
            }
        };

        Runnable r2 = () -> System.out.println("test");
    }
}

package com.example;

import io.quarkus.hibernate.orm.panache.PanacheRepository;

public class CarRepository implements PanacheRepository<CarDomain> {


}

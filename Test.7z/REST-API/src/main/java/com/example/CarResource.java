package com.example;

import javax.inject.Inject;
import javax.persistence.metamodel.ListAttribute;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.util.List;

import static org.jboss.resteasy.reactive.RestResponse.StatusCode.NO_CONTENT;

@Path("/Car")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CarResource {
//
//    @Inject
//    CarRepository carRepository;
//
//    @GET
//    public Response getAll() {
//        List<CarDomain> cardomains = carRepository.listAll();
//        return Response.ok(cardomains).build();
//    }
//
//    @GET
//    @Path("{id}")
//    public  Response getById(@PathParam("id") Long id){
//        return  carRepository.findByIdOptional(id)
//                .map(cardxomain -> Response.ok(cardomain).build() )
//                .orElse(Response.status(NO_CONTENT).build());
//    }
//
//    @GET
//    @Path("model/{model}")
//    public Response getbyModel(@PathParam("model") String model){
//        return carRepository.find("model", model)
//                .singleResultOptional()
//                .map(cardomain -> Response.ok(cardomain).build())
//                .orElse(Response.status(NO_CONTENT).build());
//    }
//
//    @GET
//    @Path("newold/{newold}")
//    public Response getbyNewold(@PathParam("newold") String newold){
//        return carRepository.find("model", newold)
//                .singleResultOptional()
//                .map(cardomain -> Response.ok(cardomain).build())
//                .orElse(Response.status(NO_CONTENT).build());
//    }
//
//    @GET
//    @Path("Country/{Country}")
//    public Response getbyCountry(@PathParam("Country") String Country){
//        return carRepository.find("model", Country)
//                .singleResultOptional()
//                .map(cardomain -> Response.ok(cardomain).build())
//                .orElse(Response.status(NO_CONTENT).build());
//    }
//    @POST
//    @Transactional
//    public Response create(CarDomain cardomain){
//       if (carRepository.isPersistent(cardomain)){
//           return  Response.created(URI.create("/car/" + cardomain.getId())).build();
//       }
//        return null;
//    }


    @GET
    public List<CarDomain> list(){
         return CarDomain.listAll();

    }
    @GET
    @Path("/{id}")
    public CarDomain get(Long id) {
        return CarDomain.findById(id);
    }

    @POST
    @Transactional
    public Response create(CarDomain person) {
        person.persist();
        return Response.created(URI.create("/persons/" + person.id)).build();
    }

    //    @GET
//    @Produces(MediaType.TEXT_PLAIN)
//    public String hello() {
//        return "Hello from RESTEasy Reactive";
//    }

    }
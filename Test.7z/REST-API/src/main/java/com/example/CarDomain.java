package com.example;


import io.quarkus.hibernate.orm.panache.PanacheEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity

public class CarDomain extends PanacheEntity {
    @Id
    @GeneratedValue
    private long id;

    @Column(length = 100)
    private String model;

    @Column(length = 100)
    private String newold;
    @Column(length = 100)
    private String Country;

    public CarDomain() {
    }

    public CarDomain(String model, String newold, String country) {
        this.model = model;
        this.newold = newold;
        Country = country;
    }


    public long getId() {
        return id;
    }

    public void setIg(long id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getNew_old() {
        return newold;
    }

    public void setNew_old(String new_old) {
        this.newold = newold;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String country) {
        Country = country;
    }
}

package car.mysql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CreateCar {
    public static void main(String[] args) {

        EntityManagerFactory car = Persistence.createEntityManagerFactory( "TestBD" );
        EntityManager entitymanager = car.createEntityManager( );
        entitymanager.getTransaction( ).begin( );


        CarDomain cardomain = new CarDomain();

        cardomain.setId(2);
        cardomain.setName("Audi");
        cardomain.setModel("A4");


        entitymanager.persist( cardomain );
        entitymanager.getTransaction( ).commit( );

        entitymanager.close( );
        car.close( );
    }
}

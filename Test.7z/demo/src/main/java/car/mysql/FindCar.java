package car.mysql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindCar {
    public static void main(String[] args) {
        EntityManagerFactory car = Persistence.createEntityManagerFactory( "TestBD" );
        EntityManager entitymanager = car.createEntityManager( );
        entitymanager.getTransaction( ).begin( );

        CarDomain cardomain = entitymanager.find( CarDomain.class, 1);

        //before update
        System.out.println("Id = "+ cardomain.getId());
        System.out.println("Name = "+ cardomain.getName());
        System.out.println("Model = "+ cardomain.getModel());

        entitymanager.close( );
        car.close( );


    }
}


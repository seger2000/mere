package car.mysql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

public class QueryCar {
    public static void main(String[] args) {
        EntityManagerFactory car = Persistence.createEntityManagerFactory("TestBD");
        EntityManager entitymanager = car.createEntityManager();

        Query query = entitymanager.createQuery("select upper(e.model) from CarDomain e");
        List<String> list = query.getResultList();

        for (String e:list){
            System.out.println("Modelul " + e);
        }
    }

}

package car.mysql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UpdateCar {

    public static void main(String[] args) {
        EntityManagerFactory car = Persistence.createEntityManagerFactory( "TestBD" );
        EntityManager entitymanager = car.createEntityManager( );
        entitymanager.getTransaction( ).begin( );

        CarDomain cardomain = entitymanager.find( CarDomain.class, 2);

        //before update
        System.out.println( cardomain );
        cardomain.setName("Audi");
        cardomain.setModel("Q8");
        entitymanager.getTransaction( ).commit( );

        //after update
        System.out.println( cardomain );
        entitymanager.close();
        car.close();

    }
}
